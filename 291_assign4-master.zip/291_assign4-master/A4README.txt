Assignment #4
|–––––––––––––––––––––––––––––––|–––––––––––––––––––––––––––––––|
| 		Name		            |		CCID 		            |	
|–––––––––––––––––––––––––––––––|–––––––––––––––––––––––––––––––|				
|	Asma Omar		            |		aaali		            |
|	Joe Ha			            |		joe2		            |
|	Debangana Ghosh		        |		debangan	            |
|–––––––––––––––––––––––––––––––|–––––––––––––––––––––––––––––––|

Collaborated with: We did not collaborate with anyone else.
Sources: stackoverflow.com for CSS/html/flask
https://www.fullstackpython.com/flask.html

##########################################
How to use web interface
##########################################
To run please use commands:
Pip3 install flask
Python3 handle_request.py
Please run web interface on incognito browser or else results will cache.
